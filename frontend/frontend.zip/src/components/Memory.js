import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Memory = () => {
  const [memory, setMemory] = useState({
    family_friends: [],
    favorites: [],
    opinions: [],
    skills: [],
    personality: [],
    others: []
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [newItem, setNewItem] = useState('');

  const categoryLabels = {
    family_friends: 'Aile & Arkadaşlar',
    favorites: 'Sevdikleri',
    opinions: 'Görüşler',
    skills: 'Yetenekler',
    personality: 'Kişilik',
    others: 'Diğer'
  };

  const categoryIcons = {
    family_friends: '👨‍👩‍👧‍👦',
    favorites: '❤️',
    opinions: '💭',
    skills: '🎯',
    personality: '🌟',
    others: '📝'
  };

  useEffect(() => {
    loadMemory();
  }, []);

  const loadMemory = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/memory');
      if (response.data.success) {
        setMemory(response.data.memory);
      }
    } catch (error) {
      console.error('Memory yüklenirken hata:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveMemory = async () => {
    try {
      setSaving(true);
      const response = await axios.put('/api/memory', memory);
      if (response.data.success) {
        // Success feedback could be added here
      }
    } catch (error) {
      console.error('Memory kaydedilirken hata:', error);
    } finally {
      setSaving(false);
    }
  };

  const addItem = (category) => {
    if (newItem.trim()) {
      const updatedMemory = {
        ...memory,
        [category]: [...memory[category], newItem.trim()]
      };
      setMemory(updatedMemory);
      setNewItem('');
      setEditingCategory(null);
    }
  };

  const removeItem = (category, index) => {
    const updatedMemory = {
      ...memory,
      [category]: memory[category].filter((_, i) => i !== index)
    };
    setMemory(updatedMemory);
  };

  const clearAllMemory = async () => {
    if (window.confirm('Tüm memory verilerini silmek istediğinizden emin misiniz?')) {
      try {
        await axios.delete('/api/memory/clear');
        setMemory({
          family_friends: [],
          favorites: [],
          opinions: [],
          skills: [],
          personality: [],
          others: []
        });
      } catch (error) {
        console.error('Memory temizlenirken hata:', error);
      }
    }
  };

  const handleKeyPress = (e, category) => {
    if (e.key === 'Enter') {
      addItem(category);
    } else if (e.key === 'Escape') {
      setEditingCategory(null);
      setNewItem('');
    }
  };

  if (loading) {
    return (
      <div className="memory-container">
        <div className="loading-message">
          <div className="loading-spinner"></div>
          <p>Memory yükleniyor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="memory-container">
      <div className="memory-header">
        <h2>🧠 Kişisel Memory</h2>
        <p>
          Sohbet sırasında öğrenilen kişisel bilgileriniz burada saklanır ve 
          gelecekteki yanıtları kişiselleştirmek için kullanılır.
        </p>
        <div className="memory-actions">
          <button 
            className="save-memory-btn" 
            onClick={saveMemory}
            disabled={saving}
          >
            {saving ? 'Kaydediliyor...' : '💾 Kaydet'}
          </button>
          <button 
            className="clear-memory-btn" 
            onClick={clearAllMemory}
          >
            🗑️ Tümünü Temizle
          </button>
        </div>
      </div>

      <div className="memory-categories">
        {Object.keys(categoryLabels).map(category => (
          <div key={category} className="memory-category">
            <div className="category-header">
              <h3>
                <span className="category-icon">{categoryIcons[category]}</span>
                {categoryLabels[category]}
                <span className="item-count">({memory[category].length})</span>
              </h3>
              <button 
                className="add-item-btn"
                onClick={() => setEditingCategory(category)}
              >
                + Ekle
              </button>
            </div>

            <div className="category-content">
              {memory[category].length === 0 ? (
                <div className="empty-category">
                  <p>Henüz {categoryLabels[category].toLowerCase()} bilgisi yok</p>
                  <small>Sohbet ederken otomatik olarak eklenecek</small>
                </div>
              ) : (
                <div className="memory-items">
                  {memory[category].map((item, index) => (
                    <div key={index} className="memory-item">
                      <span className="item-text">{item}</span>
                      <button 
                        className="remove-item-btn"
                        onClick={() => removeItem(category, index)}
                        title="Sil"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {editingCategory === category && (
                <div className="add-item-form">
                  <input
                    type="text"
                    value={newItem}
                    onChange={(e) => setNewItem(e.target.value)}
                    onKeyPress={(e) => handleKeyPress(e, category)}
                    placeholder={`Yeni ${categoryLabels[category].toLowerCase()} ekle...`}
                    autoFocus
                  />
                  <div className="form-actions">
                    <button onClick={() => addItem(category)}>Ekle</button>
                    <button onClick={() => {
                      setEditingCategory(null);
                      setNewItem('');
                    }}>İptal</button>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="memory-info">
        <h4>💡 Nasıl Çalışır?</h4>
        <ul>
          <li>Sohbet ederken bahsettiğiniz kişisel bilgiler otomatik olarak kategorilere ayrılır</li>
          <li>Bu bilgiler gelecekteki yanıtları size özel hale getirmek için kullanılır</li>
          <li>İstediğiniz zaman manuel olarak bilgi ekleyebilir veya silebilirsiniz</li>
          <li>Tüm veriler güvenli bir şekilde saklanır ve sadece sizin erişiminizde</li>
        </ul>
      </div>
    </div>
  );
};

export default Memory;
