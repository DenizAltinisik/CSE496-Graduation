import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Profile = ({ handlePersonaUpdate }) => {
  const [persona, setPersona] = useState({
    role: 'friend',
    backstory: '',
    personality_traits: [],
    interests: []
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const roleOptions = [
    { value: 'friend', label: '👫 Arkadaş', description: 'Samimi ve destekleyici', image: 'friend.png' },
    { value: 'boyfriend', label: '💙 Erkek Arkadaş', description: 'Romantik ve koruyucu', image: 'boyfriend.png' },
    { value: 'girlfriend', label: '💖 Kız Arkadaş', description: 'Romantik ve şefkatli', image: 'girlfriend.png' },
    { value: 'spouse_male', label: '💍 Eş (Erkek)', description: 'Derin bağlılık ve ortaklık', image: 'spouse_male.png' },
    { value: 'spouse_female', label: '💍 Eş (Kadın)', description: 'Derin bağlılık ve ortaklık', image: 'spouse_female.png' },
    { value: 'brother', label: '👨 Kardeş', description: 'Koruyucu ve şakacı', image: 'brother.png' },
    { value: 'sister', label: '👩 Kız Kardeş', description: 'Şefkatli ve anlayışlı', image: 'sister.png' },
    { value: 'mentor', label: '🎓 Mentor', description: 'Bilge ve yönlendirici', image: 'mentor.png' },
    { value: 'advisor', label: '💼 Danışman', description: 'Profesyonel ve analitik', image: 'advisor.png' },
    { value: 'academician', label: '📚 Akademisyen', description: 'Bilimsel ve eğitici', image: 'academician.png' }
  ];

  const personalityTraits = [
    'Confident', 'Shy', 'Energetic', 'Mellow', 'Caring', 
    'Sassy', 'Practical', 'Dreamy', 'Artistic', 'Logical'
  ];

  const interests = [
    'Board games', 'Comics', 'Manga', 'History', 'Philosophy',
    'Cooking & Baking', 'Anime', 'Basketball', 'Football', 'Sci-fi',
    'Sneakers', 'Gardening', 'Skincare & Makeup', 'Cars', 'Space',
    'Soccer', 'K-pop', 'Fitness', 'Physics', 'Mindfulness'
  ];

  useEffect(() => {
    loadPersona();
  }, []);

  const loadPersona = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/api/persona');
      if (response.data.success) {
        setPersona(response.data.persona);
      }
    } catch (error) {
      console.error('Persona yüklenirken hata:', error);
    } finally {
      setLoading(false);
    }
  };

  const savePersona = async () => {
    try {
      setSaving(true);
      const response = await axios.put('/api/persona', persona);
      if (response.data.success) {
        if (handlePersonaUpdate) {
          handlePersonaUpdate(persona);
        }
      }
    } catch (error) {
      console.error('Persona kaydedilirken hata:', error);
    } finally {
      setSaving(false);
    }
  };

  const resetPersona = async () => {
    if (window.confirm('AI kişiliğini varsayılan ayarlara sıfırlamak istediğinizden emin misiniz?')) {
      try {
        await axios.delete('/api/persona/reset');
        setPersona({
          role: 'friend',
          backstory: '',
          personality_traits: [],
          interests: []
        });
      } catch (error) {
        console.error('Persona sıfırlanırken hata:', error);
      }
    }
  };

  const handleRoleChange = (role) => {
    setPersona({ ...persona, role });
  };

  const handleBackstoryChange = (e) => {
    setPersona({ ...persona, backstory: e.target.value });
  };

  const toggleTrait = (trait) => {
    const currentTraits = persona.personality_traits;
    const newTraits = currentTraits.includes(trait)
      ? currentTraits.filter(t => t !== trait)
      : [...currentTraits, trait];
    setPersona({ ...persona, personality_traits: newTraits });
  };

  const toggleInterest = (interest) => {
    const currentInterests = persona.interests;
    const newInterests = currentInterests.includes(interest)
      ? currentInterests.filter(i => i !== interest)
      : [...currentInterests, interest];
    setPersona({ ...persona, interests: newInterests });
  };

  if (loading) {
    return (
      <div className="profile-container">
        <div className="loading-message">
          <div className="loading-spinner"></div>
          <p>Profil yükleniyor...</p>
        </div>
      </div>
    );
  }

  const selectedRole = roleOptions.find(role => role.value === persona.role);

  return (
    <div className="profile-container">
      <div className="profile-header">
        <h2>👤 AI Kişiliği</h2>
        <p>
          AI asistanınızın kim olduğunu, nasıl davranacağını ve hangi konularda 
          uzman olacağını belirleyin.
        </p>
        <div className="profile-actions">
          <button 
            className="save-profile-btn" 
            onClick={savePersona}
            disabled={saving}
          >
            {saving ? 'Kaydediliyor...' : '💾 Kaydet'}
          </button>
          <button 
            className="reset-profile-btn" 
            onClick={resetPersona}
          >
            🔄 Sıfırla
          </button>
        </div>
      </div>

      {/* Role Selection */}
      <div className="profile-section">
        <h3>🎭 AI'ın Rolü</h3>
        <p className="section-description">
          AI asistanınızın sizinle nasıl bir ilişkisi olacağını seçin
        </p>
        <div className="role-grid">
          {roleOptions.map(role => (
            <div 
              key={role.value}
              className={`role-card ${persona.role === role.value ? 'selected' : ''}`}
              onClick={() => handleRoleChange(role.value)}
            >
              <img 
                src={`/drawing/${role.image}`} 
                alt={role.label} 
                className="role-image"
              />
              <div className="role-label">{role.label}</div>
              <div className="role-description">{role.description}</div>
            </div>
          ))}
        </div>
        {selectedRole && (
          <div className="current-selection">
            <strong>Seçili:</strong> {selectedRole.label} - {selectedRole.description}
          </div>
        )}
      </div>

      {/* Backstory */}
      <div className="profile-section">
        <h3>📖 Kişilik Hikayesi</h3>
        <p className="section-description">
          Bu metin AI'ın nasıl davranacağını etkiler. Kişiliğini şekillendirir.
        </p>
        <textarea
          className="backstory-input"
          value={persona.backstory}
          onChange={handleBackstoryChange}
          placeholder="Örnek: Sen çok anlayışlı ve sabırlı birisin. Her zaman pozitif bakmaya çalışır, insanlara umut verirsin. Zor durumlarla karşılaştığında sakin kalır ve pratik çözümler sunarsin..."
          rows={6}
        />
        <div className="character-count">
          {persona.backstory.length}/500 karakter
        </div>
      </div>

      {/* Personality Traits */}
      <div className="profile-section">
        <h3>🌟 Kişilik Özellikleri</h3>
        <p className="section-description">
          AI'ın sahip olmasını istediğiniz kişilik özelliklerini seçin (çoklu seçim)
        </p>
        <div className="traits-grid">
          {personalityTraits.map(trait => (
            <button
              key={trait}
              className={`trait-button ${persona.personality_traits.includes(trait) ? 'selected' : ''}`}
              onClick={() => toggleTrait(trait)}
            >
              {trait}
            </button>
          ))}
        </div>
        <div className="selection-count">
          {persona.personality_traits.length} özellik seçildi
        </div>
      </div>

      {/* Interests */}
      <div className="profile-section">
        <h3>❤️ İlgi Alanları</h3>
        <p className="section-description">
          AI'ın hangi konularda bilgili ve ilgili olmasını istediğinizi seçin (çoklu seçim)
        </p>
        <div className="interests-grid">
          {interests.map(interest => (
            <button
              key={interest}
              className={`interest-button ${persona.interests.includes(interest) ? 'selected' : ''}`}
              onClick={() => toggleInterest(interest)}
            >
              {interest}
            </button>
          ))}
        </div>
        <div className="selection-count">
          {persona.interests.length} ilgi alanı seçildi
        </div>
      </div>

      <div className="profile-info">
        <h4>💡 Nasıl Çalışır?</h4>
        <ul>
          <li>Seçtiğiniz rol AI'ın genel davranış tarzını belirler</li>
          <li>Kişilik hikayesi AI'ın karakterini derinlemesine şekillendirir</li>
          <li>Kişilik özellikleri AI'ın yanıt verme tarzını etkiler</li>
          <li>İlgi alanları AI'ın hangi konularda daha detaylı bilgi vereceğini belirler</li>
          <li>Tüm ayarlar anında etkili olur ve sohbetlerinizi kişiselleştirir</li>
        </ul>
      </div>
    </div>
  );
};

export default Profile;
