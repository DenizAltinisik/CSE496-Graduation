import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Diary.css';

const Diary = () => {
    const [diaryEntries, setDiaryEntries] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        fetchDiaryEntries();
        
        // Set up auto-refresh every 10 seconds to show live updates
        const interval = setInterval(fetchDiaryEntries, 10000);
        
        return () => clearInterval(interval);
    }, []);

    const fetchDiaryEntries = async () => {
        try {
            setLoading(true);
            const response = await axios.get('/api/diary');
            setDiaryEntries(response.data.diary_entries || []);
        } catch (error) {
            console.error('Diary entries fetch error:', error);
            setError('Günlük girişleri yüklenemedi');
        } finally {
            setLoading(false);
        }
    };

    const deleteDiaryEntry = async (entryId) => {
        try {
            await axios.delete(`/api/diary/${entryId}`);
            setDiaryEntries(diaryEntries.filter(entry => entry._id !== entryId));
        } catch (error) {
            console.error('Diary entry deletion error:', error);
            setError('Günlük girişi silinemedi');
        }
    };

    const formatDate = (dateString) => {
        const date = new Date(dateString);
        return date.toLocaleDateString('tr-TR', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    if (loading) {
        return (
            <div className="diary-container">
                <div className="loading">Günlük girişleri yükleniyor...</div>
            </div>
        );
    }

    return (
        <div className="diary-container">
            <div className="diary-header">
                <h2>📖 Günlüğüm</h2>
                <p>Chat konuşmalarınızın özetleri otomatik olarak burada saklanır</p>
            </div>

            {error && (
                <div className="error-message">
                    {error}
                </div>
            )}

            <div className="diary-entries">
                {diaryEntries.length === 0 ? (
                    <div className="empty-diary">
                        <div className="empty-icon">📝</div>
                        <h3>Henüz günlük girişiniz yok</h3>
                        <p>Chat konuşmalarınız tamamlandıktan sonra günlük girişi otomatik olarak oluşturulur</p>
                    </div>
                ) : (
                    diaryEntries.map((entry) => (
                        <div key={entry._id} className="diary-entry">
                            <div className="entry-header">
                                <h3 className="entry-title">{entry.title}</h3>
                                <div className="entry-meta">
                                    <span className="entry-date">{formatDate(entry.date)}</span>
                                    <span className="message-count">{entry.message_count} mesaj</span>
                                    <button 
                                        className="delete-btn"
                                        onClick={() => deleteDiaryEntry(entry._id)}
                                        title="Sil"
                                    >
                                        🗑️
                                    </button>
                                </div>
                            </div>
                            <div className="entry-summary">
                                {entry.summary}
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

export default Diary;
